# Express Açougue e Mercearia - Landing Page

Landing page moderna e responsiva para o Express Açougue e Mercearia, desenvolvida em HTML, CSS e JavaScript puro para compatibilidade total com GitHub Pages.

## 🚀 Deploy no GitHub Pages

### Passo a Passo:

1. **Criar repositório no GitHub**
   - Acesse [GitHub.com](https://github.com)
   - Clique em "New repository"
   - Nome sugerido: `express-acougue-site`
   - Marque como "Public"
   - Clique em "Create repository"

2. **Upload dos arquivos**
   - Faça upload de todos os arquivos desta pasta para o repositório
   - Estrutura necessária:
     ```
     /
     ├── index.html
     ├── css/
     │   └── style.css
     ├── js/
     │   └── script.js
     ├── images/
     │   ├── carnes_variadas.jpg
     │   ├── cortes_premium.jpg
     │   ├── carne_tabua.jpg
     │   ├── acougue_moderno.jpg
     │   ├── acougueiro_profissional.jpg
     │   └── interior_acougue.jpg
     └── README.md
     ```

3. **Ativar GitHub Pages**
   - No repositório, vá em "Settings"
   - Role até a seção "Pages"
   - Em "Source", selecione "Deploy from a branch"
   - Em "Branch", selecione "main" (ou "master")
   - Em "Folder", selecione "/ (root)"
   - Clique em "Save"

4. **Acessar o site**
   - Aguarde alguns minutos
   - O site estará disponível em: `https://[seu-usuario].github.io/[nome-do-repositorio]`
   - Exemplo: `https://joaosilva.github.io/express-acougue-site`

## 📱 Características

### ✨ Design Moderno
- Layout responsivo para desktop, tablet e mobile
- Animações suaves e micro-interações
- Tema preto e laranja conforme solicitado
- Tipografia moderna e hierarquia visual clara

### 🖼️ Imagens Profissionais
- 6 imagens de alta qualidade relacionadas ao açougue
- Otimizadas para web
- Efeitos hover e zoom

### 🎯 Seções Incluídas
- **Hero**: Apresentação principal com call-to-actions
- **Diferenciais**: Qualidade Premium, Cortes Especiais, Atendimento Familiar
- **Produtos**: Galeria visual dos produtos
- **Sobre**: História e estatísticas do negócio
- **Contato**: Informações completas e botões de ação

### 🔧 Funcionalidades
- Navegação suave entre seções
- Menu mobile responsivo
- Botões funcionais para WhatsApp e Instagram
- Animações de scroll
- Efeitos de hover em cards e botões
- Contador animado nas estatísticas

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Estilos modernos com Flexbox e Grid
- **JavaScript**: Interatividade e animações
- **Font Awesome**: Ícones profissionais

## 📞 Personalização

### Alterar informações de contato:
1. **WhatsApp**: Edite o número no arquivo `js/script.js` (linha com `5511999999999`)
2. **Instagram**: Confirme o usuário `@express.a_m` no HTML
3. **Endereço**: Já configurado com o endereço atual

### Adicionar mais produtos:
1. Adicione novas imagens na pasta `images/`
2. Edite o arquivo `index.html` na seção de produtos
3. Mantenha a estrutura dos cards existentes

### Alterar cores:
1. Edite as variáveis CSS no arquivo `css/style.css`
2. Procure por `:root` no início do arquivo
3. Modifique as cores conforme necessário

## 📊 Performance

- **Carregamento rápido**: Código otimizado
- **SEO friendly**: Meta tags configuradas
- **Acessibilidade**: Contraste adequado e navegação por teclado
- **Mobile first**: Design responsivo

## 🔄 Atualizações Futuras

Sugestões para melhorias:
- Integração com Google Analytics
- Formulário de contato funcional
- Sistema de depoimentos
- Galeria expandida de produtos
- Blog/notícias

## 📝 Licença

Este projeto foi desenvolvido especificamente para o Express Açougue e Mercearia.

---

**Desenvolvido com ❤️ para o Express Açougue e Mercearia**

